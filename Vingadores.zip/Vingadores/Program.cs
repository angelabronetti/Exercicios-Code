﻿using System;
using Vingadores.Controller;

namespace Vingadores
{
    class Program
    {
        static void Main(string[] args)
        {

            TimeController time = new TimeController();

            time.MenuInicial();

        }
    }
}
